public class BookCopy {

    //TODO
}
